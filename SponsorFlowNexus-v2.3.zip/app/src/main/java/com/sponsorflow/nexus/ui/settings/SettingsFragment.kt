/*
 * SponsorFlow Nexus v2.3 - Settings Fragment
 */
package com.sponsorflow.nexus.ui.settings

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Switch
import androidx.fragment.app.Fragment
import com.sponsorflow.nexus.R

class SettingsFragment : Fragment() {

    private lateinit var autoReplySwitch: Switch
    private lateinit var notificationSwitch: Switch

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_settings, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        autoReplySwitch = view.findViewById(R.id.switch_auto_reply)
        notificationSwitch = view.findViewById(R.id.switch_notifications)
        loadSettings()
    }

    private fun loadSettings() {
        val prefs = requireContext().getSharedPreferences("nexus_settings", 0)
        autoReplySwitch.isChecked = prefs.getBoolean("auto_reply", true)
        notificationSwitch.isChecked = prefs.getBoolean("notifications", true)
    }

    private fun saveSettings() {
        val prefs = requireContext().getSharedPreferences("nexus_settings", 0)
        prefs.edit()
            .putBoolean("auto_reply", autoReplySwitch.isChecked)
            .putBoolean("notifications", notificationSwitch.isChecked)
            .apply()
    }

    override fun onPause() {
        super.onPause()
        saveSettings()
    }
}