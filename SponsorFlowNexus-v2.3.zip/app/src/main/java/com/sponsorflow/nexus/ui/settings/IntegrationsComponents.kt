/*
 * SponsorFlow Nexus - Integrations Components
 */
package com.sponsorflow.nexus.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun PlanLockedBanner() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Lock, "Bloqueado", tint = MaterialTheme.colorScheme.error)
            Spacer(Modifier.width(12.dp))
            Text(
                "Activa el plan EMPRESARIO para conectar tu tienda online",
                color = MaterialTheme.colorScheme.onErrorContainer
            )
        }
    }
}

@Composable
fun IntegrationInfoCard() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Link, "Integración", tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text("Conecta con Zapier o N8N", style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Recibe notificaciones automáticas cuando ocurran eventos en tu negocio",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
fun AvailableEventsList() {
    Text(
        "Eventos disponibles:",
        style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.padding(16.dp)
    )
    
    listOf(
        "payment_success" to "Cuando se completa un pago",
        "license_activated" to "Cuando se activa una licencia",
        "order_created" to "Cuando se crea una orden"
    ).forEach { (event, desc) ->
        ListItem(
            headlineContent = { Text(event) },
            supportingContent = { Text(desc) },
            leadingContent = {
                Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
            }
        )
    }
}