/*
 * SponsorFlow Nexus v2.3 - Offline Database (Encrypted with SQLCipher)
 */
package com.sponsorflow.nexus.offline

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory
import java.io.File

@Database(
    entities = [OfflineQueueEntity::class],
    version = 1,
    exportSchema = false
)
abstract class OfflineDatabase : RoomDatabase() {
    
    abstract fun offlineQueueDao(): OfflineQueueDao
    
    companion object {
        private const val DB_NAME = "nexus_offline_queue_encrypted.db"
        
        @Volatile
        private var INSTANCE: OfflineDatabase? = null
        
        fun getInstance(context: Context): OfflineDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context).also { INSTANCE = it }
            }
        }
        
        private fun buildDatabase(context: Context): OfflineDatabase {
            // Generar passphrase desde Android Keystore
            val passphrase = getOrCreatePassphrase(context)
            
            // Configurar SQLCipher
            val factory = SupportFactory(passphrase)
            
            return Room.databaseBuilder(
                context.applicationContext,
                OfflineDatabase::class.java,
                DB_NAME
            )
                .openHelperFactory(factory)
                .fallbackToDestructiveMigration()
                .build()
        }
        
        // Obtener o crear passphrase segura
        private fun getOrCreatePassphrase(context: Context): ByteArray {
            val keyFile = File(context.filesDir, ".db_key_offline")
            
            return if (keyFile.exists()) {
                keyFile.readBytes()
            } else {
                // Generar clave aleatoria de 256 bits
                val key = SQLiteDatabase.getBytes(
                    java.security.SecureRandom().generateSeed(32)
                )
                keyFile.writeBytes(key)
                // Ocultar archivo
                keyFile.setReadable(false, false)
                keyFile.setReadable(true, true)
                key
            }
        }
        
        // Migrar base de datos sin cifrar (si existe)
        fun migrateToEncrypted(context: Context) {
            val oldDb = File(context.getDatabasePath("nexus_offline_queue").absolutePath)
            if (oldDb.exists()) {
                // Eliminar base de datos antigua sin cifrar
                oldDb.delete()
                context.getDatabasePath("nexus_offline_queue-wal").delete()
                context.getDatabasePath("nexus_offline_queue-shm").delete()
            }
        }
    }
}
