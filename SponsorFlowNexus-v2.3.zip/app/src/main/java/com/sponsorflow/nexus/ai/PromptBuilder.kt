/*
 * SponsorFlow Nexus v2.4 - Prompt Builder
 */
package com.sponsorflow.nexus.ai

import com.sponsorflow.nexus.core.enums.SubscriptionTier

class PromptBuilder(
    private val customPrompt: String? = null,
    private val tier: SubscriptionTier
) {

    fun buildPrompt(context: PromptContext): String {
        val systemPrompt = buildSystemPrompt()
        val memoryContext = buildMemoryContext(context.recentMessages)
        val productContext = buildProductContext(context.relevantProducts)
        val salesTactics = buildSalesTactics()
        
        return buildString {
            append(systemPrompt)
            append("\n\n")
            if (salesTactics.isNotEmpty()) {
                append("Tácticas de venta:\n$salesTactics\n\n")
            }
            if (memoryContext.isNotEmpty()) {
                append("Historial de conversación:\n$memoryContext\n\n")
            }
            if (productContext.isNotEmpty()) {
                append("Productos disponibles:\n$productContext\n\n")
            }
            append("Cliente: ${context.userMessage}\n")
            append("Asistente:")
        }
    }

    private fun buildSystemPrompt(): String {
        return when {
            tier.hasCustomPrompt && customPrompt != null -> customPrompt
            else -> getPromptByTier()
        }
    }
    
    private fun getPromptByTier(): String {
        return when (tier) {
            SubscriptionTier.FREE -> FREE_TIER_PROMPT
            SubscriptionTier.OBSERVADOR -> OBSERVADOR_TIER_PROMPT
            SubscriptionTier.DESARROLLO -> DESARROLLO_TIER_PROMPT
            SubscriptionTier.EMPRESARIO -> EMPRESARIO_TIER_PROMPT
        }
    }
    
    private fun buildSalesTactics(): String {
        return when (tier) {
            SubscriptionTier.FREE -> ""
            SubscriptionTier.OBSERVADOR -> OBSERVADOR_SALES_TACTICS
            SubscriptionTier.DESARROLLO -> DESARROLLO_SALES_TACTICS
            SubscriptionTier.EMPRESARIO -> EMPRESARIO_SALES_TACTICS
        }
    }

    private fun buildMemoryContext(messages: List<String>): String {
        if (!tier.hasMemory || messages.isEmpty()) return ""
        val limit = minOf(messages.size, tier.memoryLimit)
        return messages.takeLast(limit).joinToString("\n")
    }

    private fun buildProductContext(products: List<ProductInfo>): String {
        if (!tier.hasInventory || products.isEmpty()) return ""
        return products.joinToString("\n") { 
            "- ${it.name}: ${it.price} ${it.currency}${it.description?.let { d -> " - $d" } ?: ""}"
        }
    }

    companion object {
        private const val FREE_TIER_PROMPT = """
Eres un asistente de atención al cliente básico.
Responde de forma amable y breve.
Deriva preguntas complejas a un humano.
Máximo 2 oraciones por respuesta.
"""
        
        private const val OBSERVADOR_TIER_PROMPT = """
Eres un vendedor profesional de una tienda en línea.
Tu objetivo es ayudar a los clientes y cerrar ventas.

INSTRUCCIONES:
- Saluda calurosamente
- Pregunta sobre las necesidades del cliente
- Recomienda productos del catálogo
- Ofrece alternativas si no hay stock
- Cierra la venta con una pregunta directa
- Máximo 3 oraciones por respuesta

ESTILO: Profesional pero cercano.
"""
        
        private const val DESARROLLO_TIER_PROMPT = """
Eres un consultor de ventas experto con 10 años de experiencia.
Tu objetivo es MAXIMIZAR las ventas y la satisfacción del cliente.

INSTRUCCIONES:
1. ANALIZA: Identifica la intención real del cliente
2. ESCUCHA: Usa el historial para personalizar
3. ASESORA: Recomienda productos que resuelvan problemas
4. PERSUADE: Usa argumentos de valor, no de precio
5. CIERRA: Propone una acción concreta

ESTILO: Consultor experto que inspira confianza.
"""
        
        private const val EMPRESARIO_TIER_PROMPT = """
Eres un CLOSER profesional de alto rendimiento.
Tu única métrica es: VENTAS CERRADAS.

INSTRUCCIONES:
1. LEAD: Genera interés inmediato
2. QUALIFY: Confirma presupuesto, autoridad, necesidad
3. PRESENT: Presenta la solución perfecta
4. OBJECTIONS: Resuelve objecciones
5. CLOSE: Usa el cierre adecuado

ESTILO: Profesional, directo, orientado a resultados.
"""
        
        private const val OBSERVADOR_SALES_TACTICS = """
- Si pregunta precio → Menciona valor primero
- Si dice "es caro" → Ofrece alternativas
- Si no responde → Haz una pregunta abierta
"""
        
        private const val DESARROLLO_SALES_TACTICS = """
- Técnica del sandwich: Beneficio → Precio → Beneficio
- Técnica de escasez: Menciona stock limitado
- Técnica social: Menciona clientes satisfechos
"""
        
        private const val EMPRESARIO_SALES_TACTICS = """
- Anclaje: Menciona producto más caro primero
- Reciprocidad: Ofrece algo gratis antes de pedir la venta
- Social proof: Menciona casos de éxito
- Scarcity: Urgencia real
"""
    }
}

data class PromptContext(
    val userMessage: String,
    val recentMessages: List<String> = emptyList(),
    val relevantProducts: List<ProductInfo> = emptyList()
)

data class ProductInfo(
    val name: String,
    val price: Double,
    val currency: String = "USD",
    val description: String? = null
)