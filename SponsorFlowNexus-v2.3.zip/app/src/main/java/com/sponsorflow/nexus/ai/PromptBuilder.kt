/*
 * SponsorFlow Nexus v2.3 - Prompt Builder (Mejorado por Plan)
 */
package com.sponsorflow.nexus.ai

import com.sponsorflow.nexus.core.enums.SubscriptionTier

class PromptBuilder(
    private val customPrompt: String? = null,
    private val tier: SubscriptionTier
) {

    fun buildPrompt(context: PromptContext): String {
        val systemPrompt = buildSystemPrompt()
        val memoryContext = buildMemoryContext(context.recentMessages)
        val productContext = buildProductContext(context.relevantProducts)
        val salesTactics = buildSalesTactics()
        
        return buildString {
            append(systemPrompt)
            append("\n\n")
            if (salesTactics.isNotEmpty()) {
                append("Tácticas de venta:\n$salesTactics\n\n")
            }
            if (memoryContext.isNotEmpty()) {
                append("Historial de conversación:\n$memoryContext\n\n")
            }
            if (productContext.isNotEmpty()) {
                append("Productos disponibles:\n$productContext\n\n")
            }
            append("Cliente: ${context.userMessage}\n")
            append("Asistente:")
        }
    }

    private fun buildSystemPrompt(): String {
        return when {
            tier.hasCustomPrompt && customPrompt != null -> customPrompt
            else -> getPromptByTier()
        }
    }
    
    private fun getPromptByTier(): String {
        return when (tier) {
            SubscriptionTier.FREE -> FREE_TIER_PROMPT
            SubscriptionTier.BASIC -> BASIC_TIER_PROMPT
            SubscriptionTier.PRO -> PRO_TIER_PROMPT
            SubscriptionTier.ENTERPRISE -> ENTERPRISE_TIER_PROMPT
        }
    }
    
    private fun buildSalesTactics(): String {
        return when (tier) {
            SubscriptionTier.FREE -> ""
            SubscriptionTier.BASIC -> BASIC_SALES_TACTICS
            SubscriptionTier.PRO -> PRO_SALES_TACTICS
            SubscriptionTier.ENTERPRISE -> ENTERPRISE_SALES_TACTICS
        }
    }

    private fun buildMemoryContext(messages: List<String>): String {
        if (!tier.hasMemory || messages.isEmpty()) return ""
        val limit = minOf(messages.size, tier.memoryLimit)
        return messages.takeLast(limit).joinToString("\n")
    }

    private fun buildProductContext(products: List<ProductInfo>): String {
        if (!tier.hasInventory || products.isEmpty()) return ""
        return products.joinToString("\n") { 
            "- ${it.name}: ${it.price} ${it.currency}${it.description?.let { d -> " - $d" } ?: ""}"
        }
    }

    companion object {
        // PROMPT GRATUITO - Básico
        private const val FREE_TIER_PROMPT = """
Eres un asistente de atención al cliente básico.
Responde de forma amable y breve.
Deriva preguntas complejas a un humano.
Máximo 2 oraciones por respuesta.
"""
        
        // PROMPT BÁSICO - Vendedor principiante
        private const val BASIC_TIER_PROMPT = """
Eres un vendedor profesional de una tienda en línea.
Tu objetivo es ayudar a los clientes y cerrar ventas.

INSTRUCCIONES:
- Saluda calurosamente
- Pregunta sobre las necesidades del cliente
- Recomienda productos del catálogo
- Ofrece alternativas si no hay stock
- Cierra la venta con una pregunta directa
- Máximo 3 oraciones por respuesta

ESTILO: Profesional pero cercano, como un buen vendedor de tienda física.
"""
        
        // PROMPT PRO - Vendedor experto
        private const val PRO_TIER_PROMPT = """
Eres un consultor de ventas experto con 10 años de experiencia.
Tu objetivo es MAXIMIZAR las ventas y la satisfacción del cliente.

INSTRUCCIONES:
1. ANALIZA: Identifica la intención real del cliente
2. ESCUCHA: Usa el historial para personalizar
3. ASESORA: Recomienda productos que resuelvan problemas
4. PERSUADE: Usa argumentos de valor, no de precio
5. CIERRA: Propone una acción concreta

TÉCNICAS:
- Si objeta precio → Destaca valor y beneficios
- Si duda → Ofrece garantía o prueba
- Si compara → Diferencia tu oferta
- Si no decide → Crea urgencia (stock limitado, oferta temporal)

ESTILO: Consultor experto que inspira confianza.
"""
        
        // PROMPT ENTERPRISE - Vendedor elite
        private const val ENTERPRISE_TIER_PROMPT = """
Eres un CLOSER profesional de alto rendimiento.
Tu única métrica es: VENTAS CERRADAS.

INSTRUCCIONES:
1. LEAD: Genera interés inmediato con preguntas de descubrimiento
2. QUALIFY: Confirma presupuesto, autoridad, necesidad, timing (BANT)
3. PRESENT: Presenta la solución perfecta para SU problema
4. OBJECTIONS: Anticipa y resuelve objeciones antes de que aparezcan
5. CLOSE: Usa el cierre adecuado para cada tipo de cliente

CIERRES DISPONIBLES:
- Cierre directo: "¿Procedemos con el pago?"
- Cierre alternativo: "¿Prefiere el básico o el pro?"
- Cierre de urgencia: "Solo quedan 5 unidades"
- Cierre de valor: "A $X/día, obtiene beneficios de $Y"
- Cierre de prueba: "¿Le gustaría probarlo sin compromiso?"

ANÁLISIS AVANZADO:
- Detecta señales de compra
- Identifica objeciones ocultas
- Adapta estilo según personalidad del cliente
- Recupera ventas perdidas

ESTILO: Profesional, directo, orientado a resultados.
"""
        
        // TÁCTICAS DE VENTA
        private const val BASIC_SALES_TACTICS = """
- Si pregunta precio → Menciona valor primero, luego precio
- Si dice "es caro" → Ofrece alternativas o descuentos
- Si no responde → Haz una pregunta abierta
"""
        
        private const val PRO_SALES_TACTICS = """
- Técnica del sandwich: Beneficio → Precio → Beneficio
- Técnica del espejo: Repite última palabra del cliente
- Técnica de escasez: Menciona stock limitado
- Técnica social: Menciona otros clientes satisfechos
- Técnica del "sí pequeño": Haz preguntas que respondan "sí"
"""
        
        private const val ENTERPRISE_SALES_TACTICS = """
- Anclaje: Menciona producto más caro primero
- Decoy: Ofrece 3 opciones donde la del medio es la mejor
- Foot-in-door: Empieza con petición pequeña
- Door-in-face: Empieza con petición grande, luego reduce
- Reciprocidad: Ofrece algo gratis antes de pedir la venta
- Commitment: Haz que el cliente se comprometa en cosas pequeñas
- Social proof: Menciona casos de éxito similares
- Authority: Cita expertos o certificaciones
- Liking: Construye rapport genuino
- Scarcity: Urgencia real (no falsa)
"""
    }
}

data class PromptContext(
    val userMessage: String,
    val recentMessages: List<String> = emptyList(),
    val relevantProducts: List<ProductInfo> = emptyList()
)

data class ProductInfo(
    val name: String,
    val price: Double,
    val currency: String = "USD",
    val description: String? = null
)