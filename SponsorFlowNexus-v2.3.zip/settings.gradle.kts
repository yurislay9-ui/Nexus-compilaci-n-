/*
 * SponsorFlow Nexus v2.4 - Settings Configuration
 */

pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

rootProject.name = "SponsorFlowNexus"
include(":app")