# 📱 Compilar SponsorFlow Nexus en GitHub - Paso a Paso

## Requisitos Previos
- Cuenta de GitHub
- Acceso a internet

---

## Paso 1: Subir el proyecto a GitHub

### Opción A: Si ya tienes Git configurado localmente
```bash
cd /ruta/a/tu/proyecto
git init
git add .
git commit -m "SponsorFlow Nexus v2.4 - Ready for build"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/sponsorflow-nexus.git
git push -u origin main
```

### Opción B: Desde code-server
```bash
# Inicializar git
git init
git config user.name "Tu Nombre"
git config user.email "tu@email.com"

# Añadir archivos
git add .
git commit -m "SponsorFlow Nexus v2.4"

# Crear repositorio en GitHub y subir
gh repo create sponsorflow-nexus --public --source=. --push
```

---

## Paso 2: Crear el Workflow de GitHub Actions

1. En tu repositorio de GitHub, ve a **Actions** → **New workflow**
2. Click en **"set up a workflow yourself"**
3. Copia y pega este código:

```yaml
name: Build Android APK

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    name: Build Debug APK
    runs-on: ubuntu-latest
    
    steps:
      # 1. Checkout del código
      - name: Checkout code
        uses: actions/checkout@v4
      
      # 2. Configurar Java 17
      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'
          cache: gradle
      
      # 3. Configurar Android SDK
      - name: Setup Android SDK
        uses: android-actions/setup-android@v3
      
      # 4. Construir APK Debug
      - name: Build Debug APK
        run: ./gradlew assembleDebug --no-daemon
      
      # 5. Subir APK como artifact
      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: sponsorflow-nexus-debug
          path: app/build/outputs/apk/debug/app-debug.apk
```

4. Click en **"Commit changes..."**
5. Nombre: `Add Android build workflow`
6. Click **Commit changes**

---

## Paso 3: Ejecutar el Build

1. Ve a la pestaña **Actions** en tu repositorio
2. Click en **Build Android APK** (workflow)
3. Click en **Run workflow** → **Run workflow**
4. Espera ~5-10 minutos
5. Click en el workflow en ejecución
6. Verifica que el build termine en ✅ **build**

---

## Paso 4: Descargar el APK

1. Cuando termine el build, ve a **Actions** → **Build Android APK**
2. Click en el build más reciente (verde ✅)
3. En **Artifacts**, click en **sponsorflow-nexus-debug**
4. Se descargará un ZIP con el APK

---

## 🎯 Resumen de Comandos

```bash
# Desde tu terminal local o code-server:
git init
git add .
git commit -m "v2.4"
gh repo create sponsorflow --public --source=. --push
```

El resto lo hace GitHub automáticamente.

---

## ¿Necesitas ayuda?

Si no tienes `gh` instalado, puedes:
1. Ir a https://github.com/new
2. Crear repositorio manualmente
3. Subir archivos con drag & drop
