# SponsorFlow Nexus v2.3 - Planes y Mejoras

## 💰 PLANES DE SUSCRIPCIÓN (USDT TRC20)

### Plan GRATIS
```
✅ IA Local (SmolLM2-135M)
✅ 50 respuestas/día
✅ 1 número WhatsApp vinculado
✅ Plantillas básicas
❌ Sin Analytics
❌ Sin multi-idioma
```

### Plan BASICO - 9 USDT/mes
```
✅ IA Local (SmolLM2-135M)
✅ Respuestas ilimitadas
✅ 1 número WhatsApp vinculado
✅ Analytics básicos
✅ Plantillas premium
✅ Soporte email
```

### Plan PRO - 19 USDT/mes
```
✅ IA Local (SmolLM2-135M)
✅ Respuestas ilimitadas
✅ 1 número WhatsApp vinculado
✅ Analytics avanzados
✅ Multi-idioma (5 idiomas)
✅ Sentiment Analysis
✅ Integración Instagram DM
✅ Soporte prioritario
```

### Plan ENTERPRISE - 39 USDT/mes
```
✅ IA Local (SmolLM2-135M)
✅ Respuestas ilimitadas
✅ 3 números WhatsApp vinculados (máximo)
✅ Todo lo de PRO +
✅ Sistema de Plugins (instalar/crear propios)
✅ Marketplace de Plugins de terceros
✅ Integración Facebook Messenger
✅ Integración Telegram Bot
✅ WhatsApp Business API (opcional) ⭐
✅ API propia
✅ Soporte 24/7
✅ Backup automático
```

### WhatsApp Business API (Opcional - ENTERPRISE)
```
El usuario puede elegir:
✅ Usar el sistema actual de la app (accesibilidad)
✅ Usar WhatsApp Business API oficial (requiere cuenta business)

Beneficios API oficial:
- Mensajes 100% legítimos
- Sin riesgo de bloqueos
- Templates aprobados por Meta
- Métricas oficiales

Nota: El usuario paga directamente a Meta por el uso de la API.
```

---

## 🤖 IA LOCAL (Todos los planes)

Todos los planes incluyen **IA Local con SmolLM2-135M**:
- Privacidad total (procesamiento en dispositivo)
- Sin costos adicionales de API
- Funciona sin internet

### API Cloud (Opcional para usuarios)
Los usuarios pueden configurar sus propias API keys:
- OpenAI (GPT-4, GPT-3.5)
- Google Gemini
- Anthropic (Claude)
- OpenRouter

**Nota:** El usuario paga directamente a estos servicios. Nexus no cobra extra.

---

## 📊 CARACTERÍSTICAS POR PLAN

| Característica | GRATIS | BÁSICO | PRO | ENTERPRISE |
|----------------|--------|--------|-----|------------|
| Precio | $0 | 9 USDT | 19 USDT | 39 USDT |
| IA Local | ✅ | ✅ | ✅ | ✅ |
| Respuestas/día | 50 | ∞ | ∞ | ∞ |
| Números WhatsApp | 1 | 1 | 1 | 3 |
| Analytics básico | ❌ | ✅ | ✅ | ✅ |
| Analytics avanzado | ❌ | ❌ | ✅ | ✅ |
| Multi-idioma | ❌ | ❌ | ✅ | ✅ |
| Sentiment Analysis | ❌ | ❌ | ✅ | ✅ |
| Instagram DM | ❌ | ❌ | ✅ | ✅ |
| Facebook Messenger | ❌ | ❌ | ❌ | ✅ |
| Telegram Bot | ❌ | ❌ | ❌ | ✅ |
| API propia | ❌ | ❌ | ❌ | ✅ |
| Soporte | Email | Email | Prioritario | 24/7 |

---

## 🚀 ROADMAP DE IMPLEMENTACIÓN

### Fase 1 - GRATIS (Actual)
- [x] IA Local con SmolLM2-135M
- [x] 50 respuestas/día
- [x] 1 número WhatsApp
- [x] Plantillas básicas

### Fase 2 - BÁSICO (9 USDT)
- [ ] Sistema de pagos USDT TRC20
- [ ] Límites por plan
- [ ] Analytics básicos

### Fase 3 - PRO (19 USDT)
- [ ] Multi-idioma
- [ ] Sentiment Analysis
- [ ] Integración Instagram DM

### Fase 4 - ENTERPRISE (39 USDT)
- [ ] Multi-número (3 máximo)
- [ ] Integración Facebook/Telegram
- [ ] API propia

---

## 💡 DIFERENCIACIÓN EN EL MERCADO

**Ventajas únicas:**
1. IA Local gratis = Privacidad total
2. Pagos USDT TRC20 = Sin intermediarios
3. Precios bajos = Accesible para PyMEs
4. Open-source = Transparencia

**Lema:** "Tu asistente de WhatsApp que respeta tu privacidad"