# 📱 GUÍA COMPLETA: Compilar SponsorFlow Nexus desde el Móvil

## Estado del Proyecto ✅
- **Código:** Listo y actualizado
- **Build:** Configurado con AGP 7.4.2
- **Workflow:** Listo en `.github/workflows/ci.yml`

---

## Paso 1: Crear repositorio en GitHub

1. Abre **github.com** en tu navegador (Chrome/Samsung Internet)
2. Inicia sesión en tu cuenta
3. Click en **+** (arriba a la derecha)
4. Click en **New repository**
5. En **Repository name** escribe: `sponsorflow-nexus`
6. Selecciona **Public**
7. Click en **Create repository**

---

## Paso 2: Subir archivos

### Opción A: Arrastrar archivos
1. En tu repositorio nuevo, busca **"uploading an existing file"**
2. Click en ese enlace
3. Arrastra TODOS los archivos y carpetas del proyecto:
   - app/
   - gradle/
   - .github/
   - build.gradle.kts
   - settings.gradle.kts
   - gradlew
   - gradlew.bat
   - gradle.properties
   - local.properties
   - Etc.

4. Click en **Commit changes**

### Opción B: Si tienes Termux con git
```bash
cd /ruta/del/proyecto
git init
git add .
git commit -m "v2.4"
gh repo create sponsorflow-nexus --public --source=. --push
```

---

## Paso 3: El build-start automáticamente

**¡Ya no necesitas crear el workflow!** 
El archivo `.github/workflows/ci.yml` ya está incluido en los archivos subidos.

Cuando subas los archivos, GitHub Actions comenzará a compilar automáticamente.

---

## Paso 4: Esperar a que compile

1. Ve a tu repositorio en GitHub
2. Click en la pestaña **Actions**
3. Verás **Build & Release** en progreso
4. Click en el build para ver logs
5. Espera ~10-15 minutos

---

## Paso 5: Descargar el APK

1. Cuando termine (verás ✅ verde), click en el build
2. En **Artifacts**, click en **sponsorflow-nexus-debug**
3. Se descargará un archivo ZIP
4. Extrae el APK del ZIP
5. Instala en tu Android

---

## ¿Qué hacer si falla el build?

### Error común: "Permission denied"
El workflow ya tiene `chmod +x gradlew`, pero si falla, no te preocupes.

### Error: "Java not found"
El workflow configura Java 17 automáticamente.

### Error: "Android SDK not found"
El workflow configura Android SDK automáticamente.

### Ver logs:
1. Ve a **Actions**
2. Click en el build que falló
3. Click en cada paso para ver el error
4. Copia el error y pégamelo aquí

---

## Comandos útiles (si usas Termux)

```bash
# Instalar git
pkg install git

# Instalar gh (GitHub CLI)
pkg install gh

# Login a GitHub
gh auth login

# Subir cambios
git add .
git commit -m "Update"
git push
```

---

## Resumen visual

```
GitHub.com → + → New Repository
         ↓
Nombre: sponsorflow-nexus
Public: ✅
         ↓
Create repository
         ↓
Subir archivos (arrastrar)
         ↓
Ir a Actions
         ↓
Esperar ~10 min
         ↓
Descargar APK ✓
```

---

## ¿Necesitas ayuda?

Si algo falla, dime:
- ¿Qué error aparece en Actions?
- ¿Llegaste a subir los archivos?
- ¿Tienes cuenta en GitHub?
