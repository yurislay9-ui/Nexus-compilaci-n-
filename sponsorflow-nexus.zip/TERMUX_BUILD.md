# 📱 Compilar SponsorFlow Nexus en Termux

⚠️ **NOTA IMPORTANTE**: Termux en Android es ARM64 (igual que este servidor). Los tools de Android son x86_64. **NO funcionará directamente en Termux**.

---

## ✅ OPCIÓN 1: Compilar en PC (Lo recomendado)

```bash
# En tu PC con Linux/Windows/Mac:
git clone https://github.com/TU_USUARIO/sponsorflow-nexus.git
cd sponsorflow-nexus
./gradlew assembleDebug
```

---

## ✅ OPCIÓN 2: GitHub Actions (Automático)

Ya creé la guía en `GITHUB_BUILD_GUIDE.md`

```bash
# Comandos para subir a GitHub:
git init
git add .
git commit -m "v2.4"
gh repo create sponsorflow --public --source=. --push
```

Listo. GitHub compila automáticamente.

---

## ❌ Termux NO funciona

Reason: Tu Android es ARM64, las tools de Android son x86_64.
Same problem as this server.

---

## 📋 Resumen

| Método | Funciona? | Comandos |
|--------|-----------|----------|
| PC x86-64 | ✅ Sí | `./gradlew assembleDebug` |
| GitHub | ✅ Sí | `git push` + espera |
| Termux | ❌ No | - |

**Usa GitHub Actions - es automático y gratis.**
