# 📱 GUÍA COMPLETA: Compilar SponsorFlow Nexus en GitHub

## ¿Por qué GitHub?

- ✅ **Gratis** (2000 minutos/mes)
- ✅ **Servidores x86_64** - Funciona perfectamente
- ✅ **Automático** - Cada push compila
- ✅ **Sin instalar nada** - Todo en la nube

---

## OPCIÓN 1: Subir desde tu PC (Recomendado)

### Paso 1: Descarga el proyecto

Desde este code-server, descarga los archivos. Puedes usar:
- **Zip**: Ve a GitHub → Download ZIP
- **Git**: Clona el repositorio si ya existe

### Paso 2: Instala Git en tu PC

**Windows:**
```powershell
# Descarga de https://git-scm.com
```

**Linux:**
```bash
sudo apt install git
```

**Mac:**
```bash
brew install git
```

### Paso 3: Configura Git

```bash
git config --global user.name "Tu Nombre"
git config --global user.email "tu@email.com"
```

### Paso 4: Crea el repositorio

1. Ve a https://github.com/new
2. **Repository name**: `sponsorflow-nexus`
3. **Public** ✅
4. Click **Create repository**

### Paso 5: Sube los archivos

En tu PC, abre terminal y ejecuta:

```bash
# Entra a la carpeta del proyecto
cd ruta/al/proyecto

# Inicializa git
git init

# Añade todos los archivos
git add .

# Hace commit
git commit -m "SponsorFlow Nexus v2.4"

# Añade el remoto (reemplaza TU_USUARIO)
git remote add origin https://github.com/TU_USUARIO/sponsorflow-nexus.git

# Sube
git push -u origin main
```

### Paso 6: Crea el Workflow

1. Ve a tu repositorio en GitHub
2. Click en **Actions**
3. Click en **New workflow**
4. Click en **set up a workflow yourself**
5. Borra todo y pega este código:

```yaml
name: Build Android APK

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest
    
    steps:
      - name: Checkout code
        uses: actions/checkout@v4
      
      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'
          cache: gradle
      
      - name: Setup Android SDK
        uses: android-actions/setup-android@v3
      
      - name: Build Debug APK
        run: ./gradlew assembleDebug --no-daemon
      
      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: sponsorflow-nexus-debug
          path: app/build/outputs/apk/debug/app-debug.apk
```

6. Click **Commit changes...**
7. Click **Commit changes**

### Paso 7: Descarga el APK

1. Ve a **Actions**
2. Click en el build (cuando termine verá ✅)
3. Click en **sponsorflow-nexus-debug**
4. Download

---

## OPCIÓN 2: Subir desde code-server

### Paso 1: Configura Git

```bash
git config --global user.name "Tu Nombre"
git config --global user.email "tu@email.com"
```

### Paso 2: Crea el repositorio en GitHub

```bash
gh auth login
# Follow the prompts:
# - GitHub.com
# - HTTPS
# - Yes
# - Copy authentication code to browser
# - Authorize

gh repo create sponsorflow-nexus --public --source=. --push
```

### Paso 3: Crea el Workflow

Igual que en Opción 1, pasos 6 y 7.

---

## Solución de Problemas

### Error: "gh not found"
Instala gh:
```bash
curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null
sudo apt update
sudo apt install gh
```

### Error: "Permission denied"
```bash
sudo chown -R $USER:$USER .
```

### Error: "Authentication failed"
```bash
gh auth logout
gh auth login
```

---

## Resumen de Comandos

```bash
# Configurar (una vez)
git config --global user.name "Tu Nombre"
git config --global user.email "tu@email.com"

# Subir proyecto
git init
git add .
git commit -m "v2.4"
gh repo create sponsorflow-nexus --public --source=. --push

# Actualizar después
git add .
git commit -m "Update"
git push
```

---

## ¿Qué hacer mientras compila?

1. Ve a **Actions** en GitHub
2. Click en el workflow
3. Mira los logs en tiempo real
4. Espera ~10 minutos
5. Descarga el APK

---

## ¿Necesitas ayuda?

Si algo falla, dime:
- ¿Qué error aparece?
- ¿Estás usando PC o code-server?
- ¿Qué sistema operativo?
