/*
 * SponsorFlow Nexus - Inventory Management Screen
 * Gestión profesional de inventario para e-commerce
 */
package com.sponsorflow.nexus.ui.inventory

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sponsorflow.nexus.data.entity.ProductEntity
import com.sponsorflow.nexus.data.entity.StockStatus

class InventoryViewModel : ViewModel() {
    private val _products = mutableStateListOf<ProductEntity>()
    val products: List<ProductEntity> get() = _products.toList()
    
    var searchQuery by mutableStateOf("")
        private set
    
    var showAddDialog by mutableStateOf(false)
        private set
    
    init {
        loadProducts()
    }
    
    private fun loadProducts() {
        // Datos de ejemplo
        _products.addAll(listOf(
            ProductEntity(1, "SKU-001", "Camiseta Premium", "Algodón 100%", 29.99, 15.0, 50, 10, "Ropa"),
            ProductEntity(2, "SKU-002", "Zapatillas Sport", "Running", 89.99, 45.0, 3, 5, "Calzado"),
            ProductEntity(3, "SKU-003", "Mochila Pro", "20L resistente", 45.0, 20.0, 0, 5, "Accesorios"),
            ProductEntity(4, "SKU-004", "Gorra Classic", "Ajustable", 19.99, 8.0, 25, 10, "Accesorios")
        ))
    }
    
    fun onSearchChange(query: String) { searchQuery = query }
    
    fun getFilteredProducts(): List<ProductEntity> {
        if (searchQuery.isBlank()) return products
        return products.filter { 
            it.name.contains(searchQuery, true) || it.sku.contains(searchQuery, true) 
        }
    }
    
    fun increaseStock(productId: Long) {
        val index = _products.indexOfFirst { it.id == productId }
        if (index >= 0) {
            val p = _products[index]
            _products[index] = p.copy(stockQuantity = p.stockQuantity + 1)
        }
    }
    
    fun decreaseStock(productId: Long) {
        val index = _products.indexOfFirst { it.id == productId }
        if (index >= 0) {
            val p = _products[index]
            if (p.stockQuantity > 0) {
                _products[index] = p.copy(stockQuantity = p.stockQuantity - 1)
            }
        }
    }
    
    fun addProduct(product: ProductEntity) {
        _products.add(product)
        showAddDialog = false
    }
    
    fun getStats(): InventoryStats {
        return InventoryStats(
            totalProducts = products.size,
            inStock = products.count { it.getStockStatus() == StockStatus.IN_STOCK },
            lowStock = products.count { it.getStockStatus() == StockStatus.LOW_STOCK },
            outOfStock = products.count { it.getStockStatus() == StockStatus.OUT_OF_STOCK },
            totalValue = products.sumOf { it.price * it.stockQuantity }
        )
    }
}

data class InventoryStats(
    val totalProducts: Int,
    val inStock: Int,
    val lowStock: Int,
    val outOfStock: Int,
    val totalValue: Double
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryManagementScreen(
    viewModel: InventoryViewModel = viewModel(),
    onBack: () -> Unit = {}
) {
    val stats = viewModel.getStats()
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Inventario") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.showAddDialog = true }) {
                        Icon(Icons.Default.Add, "Añadir")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Stats Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                StatCard("Total", stats.totalProducts.toString(), Color.Blue)
                StatCard("En Stock", stats.inStock.toString(), Color(0xFF4CAF50))
                StatCard("Bajo", stats.lowStock.toString(), Color(0xFFFFC107))
                StatCard("Agotado", stats.outOfStock.toString(), Color(0xFFF44336))
            }
            
            // Search
            OutlinedTextField(
                value = viewModel.searchQuery,
                onValueChange = { viewModel.onSearchChange(it) },
                label = { Text("Buscar producto...") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            )
            
            // Product List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(viewModel.getFilteredProducts()) { product ->
                    ProductCard(
                        product = product,
                        onIncrease = { viewModel.increaseStock(product.id) },
                        onDecrease = { viewModel.decreaseStock(product.id) }
                    )
                }
            }
        }
    }
    
    // Add Dialog
    if (viewModel.showAddDialog) {
        AddProductDialog(
            onDismiss = { viewModel.showAddDialog = false },
            onAdd = { viewModel.addProduct(it) }
        )
    }
}

@Composable
fun StatCard(label: String, value: String, color: Color) {
    Card(colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.1f))) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, style = MaterialTheme.typography.headlineMedium, color = color)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun ProductCard(
    product: ProductEntity,
    onIncrease: () -> Unit,
    onDecrease: () -> Unit
) {
    val statusColor = when (product.getStockStatus()) {
        StockStatus.IN_STOCK -> Color(0xFF4CAF50)
        StockStatus.LOW_STOCK -> Color(0xFFFFC107)
        StockStatus.OUT_OF_STOCK -> Color(0xFFF44336)
    }
    
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Status indicator
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .background(statusColor, RoundedCornerShape(50))
            )
            
            Spacer(Modifier.width(12.dp))
            
            // Info
            Column(modifier = Modifier.weight(1f)) {
                Text(product.name, style = MaterialTheme.typography.titleMedium)
                Text("SKU: ${product.sku}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                Text("$${String.format("%.2f", product.price)}", color = MaterialTheme.colorScheme.primary)
            }
            
            // Stock controls
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onDecrease) {
                    Icon(Icons.Default.Remove, "Reducir")
                }
                Text(
                    "${product.stockQuantity}",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
                IconButton(onClick = onIncrease) {
                    Icon(Icons.Default.Add, "Aumentar")
                }
            }
        }
    }
}

@Composable
fun AddProductDialog(
    onDismiss: () -> Unit,
    onAdd: (ProductEntity) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var sku by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("0") }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nuevo Producto") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre") })
                OutlinedTextField(sku, { sku = it }, label = { Text("SKU") })
                OutlinedTextField(price, { price = it }, label = { Text("Precio") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(stock, { stock = it }, label = { Text("Stock inicial") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isNotBlank()) {
                    onAdd(ProductEntity(
                        name = name,
                        sku = sku.ifBlank { "SKU-${System.currentTimeMillis()}" },
                        price = price.toDoubleOrNull() ?: 0.0,
                        stockQuantity = stock.toIntOrNull() ?: 0
                    ))
                }
            }) { Text("Guardar") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}