/*
 * SponsorFlow Nexus - Integrations Screen
 * Conecta con Zapier/N8N (Solo plan EMPRESARIO)
 */
package com.sponsorflow.nexus.ui.settings

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.sponsorflow.nexus.core.enums.SubscriptionTier
import com.sponsorflow.nexus.integration.UserWebhookManager
import com.sponsorflow.nexus.integration.WebhookEvent
import kotlinx.coroutines.launch

class IntegrationsViewModel(
    private val webhookManager: UserWebhookManager
) : ViewModel() {
    
    var webhookUrl by mutableStateOf("")
        private set
    
    var isLoading by mutableStateOf(false)
        private set
    
    var lastTestResult by mutableStateOf<String?>(null)
        private set
    
    init {
        webhookUrl = webhookManager.getUserWebhookUrl() ?: ""
    }
    
    fun updateUrl(url: String) {
        webhookUrl = url
    }
    
    fun saveUrl() {
        if (webhookUrl.isNotBlank()) {
            webhookManager.saveUserWebhookUrl(webhookUrl)
        } else {
            webhookManager.removeUserWebhook()
        }
    }
    
    suspend fun testWebhook(): Boolean {
        isLoading = true
        lastTestResult = null
        val result = webhookManager.testWebhook()
        isLoading = false
        lastTestResult = if (result.isSuccess) "✅ Webhook enviado correctamente" else "❌ Error: ${result.exceptionOrNull()?.message}"
        return result.isSuccess
    }
    
    suspend fun sendPaymentWebhook(orderId: String, amount: Double, customerId: String): Boolean {
        val event = WebhookEvent(
            eventType = "payment_success",
            orderId = orderId,
            amount = amount,
            customerId = customerId,
            status = "completed"
        )
        return webhookManager.sendWebhook(event).isSuccess
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IntegrationsScreen(
    viewModel: IntegrationsViewModel = viewModel(factory = viewModelFactory {
        initializer {
            val context = LocalContext.current.applicationContext
            IntegrationsViewModel(UserWebhookManager(context))
        }
    }),
    userTier: SubscriptionTier = SubscriptionTier.FREE,
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val isEmpresario = userTier == SubscriptionTier.EMPRESARIO
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Integraciones") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            // Banner de plan
            if (!isEmpresario) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Lock, "Bloqueado", tint = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.width(12.dp))
                        Text(
                            "Activa el plan EMPRESARIO para conectar tu tienda online",
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            } else {
                // Info card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Link, "Integración", tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text("Conecta con Zapier o N8N", style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Recibe notificaciones automáticas cuando ocurran eventos en tu negocio",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
                
                // URL Input
                OutlinedTextField(
                    value = viewModel.webhookUrl,
                    onValueChange = { viewModel.updateUrl(it) },
                    label = { Text("URL del Webhook") },
                    placeholder = { Text("https://hooks.zapier.com/hooks/catch/...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    singleLine = true,
                    trailingIcon = {
                        if (viewModel.webhookUrl.isNotBlank()) {
                            IconButton(onClick = { viewModel.updateUrl("") }) {
                                Icon(Icons.Default.Clear, "Limpiar")
                            }
                        }
                    }
                )
                
                // Save button
                Button(
                    onClick = {
                        viewModel.saveUrl()
                        Toast.makeText(context, "URL guardada", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    enabled = viewModel.webhookUrl.isNotBlank()
                ) {
                    Icon(Icons.Default.Save, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Guardar URL")
                }
                
                // Test button
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            val success = viewModel.testWebhook()
                            Toast.makeText(
                                context,
                                if (success) "Test exitoso" else "Test fallido",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    enabled = viewModel.webhookUrl.isNotBlank() && !viewModel.isLoading
                ) {
                    if (viewModel.isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(Icons.Default.Send, null)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("Probar Webhook")
                }
                
                // Result
                viewModel.lastTestResult?.let { result ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            result,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
                
                // Eventos disponibles
                Text(
                    "Eventos disponibles:",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(16.dp)
                )
                
                listOf(
                    "payment_success" to "Cuando se completa un pago",
                    "license_activated" to "Cuando se activa una licencia",
                    "order_created" to "Cuando se crea una orden"
                ).forEach { (event, desc) ->
                    ListItem(
                        headlineContent = { Text(event) },
                        supportingContent = { Text(desc) },
                        leadingContent = {
                            Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                        }
                    )
                }
            }
        }
    }
}