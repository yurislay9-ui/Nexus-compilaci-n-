/*
 * SponsorFlow Nexus v2.4 - Database Module (Hilt)
 * Proporciona instancias de Room y DAOs
 */
package com.sponsorflow.nexus.di

import android.content.Context
import androidx.room.Room
import com.sponsorflow.nexus.data.dao.*
import com.sponsorflow.nexus.data.database.NexusDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun providePassphrase(@ApplicationContext context: Context): ByteArray {
        // En producción, obtener desde EncryptedSharedPreferences
        // Por ahora usamos una clave derivada del keystore
        val prefs = context.getSharedPreferences("nexus_secure", Context.MODE_PRIVATE)
        val storedKey = prefs.getString("db_key", null)
        
        return if (storedKey != null) {
            storedKey.toByteArray(Charsets.UTF_8)
        } else {
            val newKey = SQLiteDatabase.getBytes("nexus_secure_key_2024".toCharArray())
            prefs.edit().putString("db_key", String(newKey, Charsets.UTF_8)).apply()
            newKey
        }
    }

    @Provides
    @Singleton
    fun provideDatabase(
        @ApplicationContext context: Context,
        passphrase: ByteArray
    ): NexusDatabase {
        val factory = SupportFactory(passphrase)
        
        return Room.databaseBuilder(
            context,
            NexusDatabase::class.java,
            "nexus_encrypted.db"
        )
            .openHelperFactory(factory)
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    fun provideContactDao(database: NexusDatabase): ContactDao = database.contactDao()

    @Provides
    fun provideTemplateDao(database: NexusDatabase): TemplateDao = database.templateDao()

    @Provides
    fun provideConversationDao(database: NexusDatabase): ConversationDao = database.conversationDao()

    @Provides
    fun provideProductDao(database: NexusDatabase): ProductDao = database.productDao()

    @Provides
    fun provideMetricDao(database: NexusDatabase): MetricDao = database.metricDao()

    @Provides
    fun provideSubscriptionDao(database: NexusDatabase): SubscriptionDao = database.subscriptionDao()
}