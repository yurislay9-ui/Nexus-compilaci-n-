/*
 * SponsorFlow Nexus v2.3 - Resource Download Manager
 */
package com.sponsorflow.nexus.ai.download

import android.content.Context
import android.util.Log
import com.sponsorflow.nexus.core.result.AppError
import com.sponsorflow.nexus.core.result.AppResult
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class ResourceDownloadManager(context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
    
    private val modelDir = File(context.filesDir, "models")
    private val validator = FileValidator()
    private val storage = StorageHelper(context)

    init {
        if (!modelDir.exists()) modelDir.mkdirs()
    }

    suspend fun downloadModel(
        url: String,
        fileName: String,
        expectedSizeMB: Int = 0,
        progress: (Int) -> Unit
    ): AppResult<File> = try {
        
        // Verificar espacio
        if (expectedSizeMB > 0 && !storage.hasSpace(expectedSizeMB)) {
            return AppResult.Error(AppError.StorageError("Espacio insuficiente"))
        }

        val file = File(modelDir, fileName)
        val tempFile = File(modelDir, validator.getTempName(fileName))

        // Verificar si ya existe válido
        if (validator.isValid(file, expectedSizeMB)) {
            return AppResult.Success(file)
        }

        // Limpiar archivos previos
        file.delete()
        tempFile.delete()

        // Descargar
        val downloaded = performDownload(url, tempFile, progress)

        // Verificar descarga
        if (!validator.isValid(tempFile, expectedSizeMB)) {
            tempFile.delete()
            return AppResult.Error(AppError.StorageError("Descarga corrupta"))
        }

        // Renombrar
        if (!tempFile.renameTo(file)) {
            tempFile.delete()
            return AppResult.Error(AppError.StorageError("Error al guardar"))
        }

        AppResult.Success(file)

    } catch (e: Exception) {
        Log.e("Nexus", "Error descarga: ${e.message}")
        cleanUp(fileName)
        AppResult.Error(AppError.fromException(e))
    }

    private fun performDownload(
        url: String,
        file: File,
        progress: (Int) -> Unit
    ): Long {
        val request = Request.Builder().url(url).build()
        val response = client.newCall(request).execute()
        
        val body = response.body ?: return 0
        val total = body.contentLength()
        var downloaded = 0L

        FileOutputStream(file).use { output ->
            body.byteStream().use { input ->
                val buffer = ByteArray(8192)
                var read: Int
                while (input.read(buffer).also { read = it } != -1) {
                    output.write(buffer, 0, read)
                    downloaded += read
                    if (total > 0) progress(((downloaded * 100) / total).toInt())
                }
            }
        }
        return downloaded
    }

    private fun cleanUp(fileName: String) {
        File(modelDir, fileName).delete()
        File(modelDir, validator.getTempName(fileName)).delete()
    }

    fun isModelDownloaded(fileName: String, expectedSizeMB: Int = 0): Boolean {
        return validator.isValid(File(modelDir, fileName), expectedSizeMB)
    }

    fun getModelPath(fileName: String): String = File(modelDir, fileName).absolutePath

    fun deleteModel(fileName: String): Boolean = cleanUp(fileName).let { true }

    fun getStorageUsageMB(): Int = storage.getUsageMB(modelDir)

    fun cleanOrphanedFiles() = storage.cleanTempFiles(modelDir)
}