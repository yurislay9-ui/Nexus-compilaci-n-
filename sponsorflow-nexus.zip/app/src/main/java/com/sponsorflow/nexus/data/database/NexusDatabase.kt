/*
 * SponsorFlow Nexus v2.3 - Room Database with SQLCipher
 * Skill: Seguridad - Base de datos cifrada
 */
package com.sponsorflow.nexus.data.database

import androidx.room.*
import com.sponsorflow.nexus.data.entity.*
import com.sponsorflow.nexus.data.dao.*
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory

@Database(
    entities = [
        ContactEntity::class,
        TemplateEntity::class,
        ConversationEntity::class,
        ProductEntity::class,
        MetricEntity::class,
        SubscriptionEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class NexusDatabase : RoomDatabase() {
    abstract fun contactDao(): ContactDao
    abstract fun templateDao(): TemplateDao
    abstract fun conversationDao(): ConversationDao
    abstract fun productDao(): ProductDao
    abstract fun metricDao(): MetricDao
    abstract fun subscriptionDao(): SubscriptionDao

    companion object {
        @Volatile
        private var INSTANCE: NexusDatabase? = null

        fun getInstance(context: android.content.Context, passphrase: ByteArray): NexusDatabase {
            return INSTANCE ?: synchronized(this) {
                val factory = SupportFactory(passphrase)
                Room.databaseBuilder(context, NexusDatabase::class.java, "nexus_encrypted.db")
                    .openHelperFactory(factory)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}