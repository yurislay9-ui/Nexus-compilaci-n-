/*
 * SponsorFlow Nexus v2.4 - App Build Configuration
 * AGP 7.4.2 para ARM64
 */

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
    id("com.google.dagger.hilt.android")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "com.sponsorflow.nexus"
    compileSdk = 34
    buildToolsVersion = "34.0.0"

    defaultConfig {
        applicationId = "com.sponsorflow.nexus"
        minSdk = 26
        targetSdk = 34
        versionCode = 24
        versionName = "2.4.0"
        
        buildConfigField("String", "CONFIG_URL", "\"${project.findProperty("CONFIG_URL") ?: ""}\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
        debug { applicationIdSuffix = ".debug" }
    }

    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { 
        viewBinding = true
        buildConfig = true
    }
}

dependencies {
    implementation("org.jetbrains.kotlin:kotlin-stdlib:1.8.20")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.5.1")
    
    implementation("androidx.core:core-ktx:1.10.1")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.9.0")
    
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.1")
    implementation("androidx.room:room-runtime:2.5.2")
    implementation("androidx.room:room-ktx:2.5.2")
    ksp("androidx.room:room-compiler:2.5.2")
    
    implementation("com.google.dagger:hilt-android:2.46")
    ksp("com.google.dagger:hilt-compiler:2.46")
    
    implementation("androidx.work:work-runtime-ktx:2.8.1")
    
    implementation("com.squareup.okhttp3:okhttp:4.11.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.11.0")
    implementation("com.google.code.gson:gson:2.10.1")
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")
    implementation("net.zetetic:android-database-sqlcipher:4.5.4")
    
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    
    implementation("androidx.navigation:navigation-fragment-ktx:2.6.0")
    implementation("androidx.navigation:navigation-ui-ktx:2.6.0")
    
    implementation("androidx.hilt:hilt-work:1.0.0")
    ksp("androidx.hilt:hilt-compiler:1.0.0")
    
    implementation("com.google.android.gms:play-services-auth:20.6.0")
    implementation("com.google.android.play:integrity:1.2.0")
    
    testImplementation("junit:junit:4.13.2")
}
