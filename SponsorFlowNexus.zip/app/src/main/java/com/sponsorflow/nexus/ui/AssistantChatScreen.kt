/*
 * SponsorFlow Nexus - Assistant Chat Screen
 * Pantalla de chat con IA para preguntas frecuentes
 */
package com.sponsorflow.nexus.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

// ==================== DATA ====================
data class ChatMessage(
    val text: String,
    val isFromUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

// ==================== VIEWMODEL ====================
class AssistantChatViewModel : ViewModel() {
    private val _messages = mutableStateListOf<ChatMessage>()
    val messages: List<ChatMessage> get() = _messages.toList()
    
    var inputText by mutableStateOf("")
        private set
    
    init {
        // Mensaje de bienvenida
        _messages.add(ChatMessage(
            text = "¡Hola! Soy el asistente de SponsorFlow Nexus. ¿En qué puedo ayudarte?",
            isFromUser = false
        ))
    }
    
    fun onInputChange(text: String) {
        inputText = text
    }
    
    fun sendMessage() {
        if (inputText.isBlank()) return
        
        // Agregar mensaje del usuario
        _messages.add(ChatMessage(text = inputText, isFromUser = true))
        val userQuestion = inputText
        inputText = ""
        
        // Generar respuesta (simulada por ahora)
        val response = generateResponse(userQuestion)
        _messages.add(ChatMessage(text = response, isFromUser = false))
    }
    
    private fun generateResponse(question: String): String {
        val q = question.lowercase()
        return when {
            q.contains("plan") || q.contains("precio") || q.contains("suscripci") ->
                "Tenemos 4 planes disponibles:\n• Gratis ($0)\n• Observador ($9/mes)\n• Desarrollo ($19/mes)\n• Empresario ($29/mes)\n\n¿Te gustaría conocer más detalles?"
            q.contains("pagar") || q.contains("pago") || q.contains("usdt") ->
                "Para pagar necesitas una wallet compatible con TRON (TronLink, Trust Wallet, SafePal). Escanea el código QR y envía el monto en USDT. La activación es automática en 1-3 minutos."
            q.contains("ia") || q.contains("memoria") ->
                "La memoria de IA varía por plan:\n• Gratis: Sin memoria\n• Observador: 5 memorias\n• Desarrollo: 20 memorias\n• Empresario: Memoria ilimitada"
            q.contains("hola") || q.contains("buenas") ->
                "¡Hola! Bienvenido a SponsorFlow Nexus. ¿En qué puedo ayudarte hoy?"
            q.contains("ayuda") || q.contains("problema") ->
                "Cuéntame tu problema y te ayudaré. Si es un error de pago, verifica tu conexión y saldo. Si la IA no carga, libera espacio (500MB mínimo)."
            else ->
                "Gracias por tu pregunta. Para más información puedes revisar la sección de ayuda o contactar a soporte@sponsorflow.com"
        }
    }
}

// ==================== SCREEN ====================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssistantChatScreen(
    viewModel: AssistantChatViewModel = viewModel(),
    onBack: () -> Unit = {}
) {
    val messages by remember { derivedStateOf { viewModel.messages } }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Asistente IA") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Área de mensajes
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 8.dp),
                reverseLayout = true
            ) {
                items(messages.reversed()) { message ->
                    MessageBubble(message = message)
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
            
            // Campo de entrada
            MessageInput(
                text = viewModel.inputText,
                onTextChange = { viewModel.onInputChange(it) },
                onSend = { viewModel.sendMessage() }
            )
        }
    }
}

@Composable
fun MessageBubble(message: ChatMessage) {
    val alignment = if (message.isFromUser) Alignment.End else Alignment.Start
    val bgColor = if (message.isFromUser) 
        MaterialTheme.colorScheme.primary 
    else 
        MaterialTheme.colorScheme.surfaceVariant
    val textColor = if (message.isFromUser) 
        Color.White 
    else 
        MaterialTheme.colorScheme.onSurfaceVariant
    
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isFromUser) 
            Arrangement.End 
        else 
            Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = bgColor,
            modifier = Modifier.fillMaxWidth(0.8f)
        ) {
            Text(
                text = message.text,
                color = textColor,
                modifier = Modifier.padding(12.dp)
            )
        }
    }
}

@Composable
fun MessageInput(
    text: String,
    onTextChange: (String) -> Unit,
    onSend: () -> Unit
) {
    Surface(
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = text,
                onValueChange = onTextChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Escribe tu pregunta...") },
                maxLines = 4
            )
            Spacer(modifier = Modifier.width(8.dp))
            FilledIconButton(
                onClick = onSend,
                enabled = text.isNotBlank()
            ) {
                Icon(Icons.Default.Send, "Enviar")
            }
        }
    }
}